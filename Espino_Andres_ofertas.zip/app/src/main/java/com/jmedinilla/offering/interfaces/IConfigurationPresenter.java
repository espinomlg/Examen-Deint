package com.jmedinilla.offering.interfaces;

/**
 * Created by usuario on 14/12/16.
 */

public interface IConfigurationPresenter {

    boolean validateData(boolean home, boolean electronic, boolean sport);


}
